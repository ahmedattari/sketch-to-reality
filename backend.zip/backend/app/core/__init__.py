# app/core/__init__.py
"""Core configuration and utilities."""