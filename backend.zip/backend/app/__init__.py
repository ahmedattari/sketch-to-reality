# app/__init__.py
"""
Sketch to Reality API
A FastAPI backend for converting sketches to realistic images using Stable Diffusion.
"""