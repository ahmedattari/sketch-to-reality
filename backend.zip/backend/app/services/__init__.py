# app/services/__init__.py
"""Service layer for business logic."""